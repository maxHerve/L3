public class Mapile  {

    // necessite les classes ExecMapile.class (dans libclass) et Mnemo.class 
    
    public static void main (String[] args) {
	ExecMapile.activer();
    }
    
} // Mapile
